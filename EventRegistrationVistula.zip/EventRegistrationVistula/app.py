import sqlite3
from flask import Flask, request, jsonify, send_from_directory
from datetime import datetime

app = Flask(__name__, static_folder='front-end', template_folder='front-end')

# Serve the main HTML page
@app.route('/')
def index():
    return send_from_directory('front-end', 'index.html')

# Serve any other files (CSS, JS, images, etc.)
@app.route('/<path:filename>')
def static_files(filename):
    return send_from_directory('front-end', filename)

# Database configuration (SQLite file path)
DATABASE = 'database.db'

# Function to initialize the database and create the table
def init_db():
    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        # Create the Registration table with all necessary columns
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS registration (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_name TEXT NOT NULL,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                phone TEXT,
                field_of_study TEXT,                    -- For 'Dzień otwartych drzwi'
                company TEXT,                           -- For 'Międzynarodowa konferencja IT'
                workshops TEXT,                         -- For 'Międzynarodowa konferencja IT'
                ticket_type TEXT,                       -- For 'Festiwal letni'
                experience_level TEXT,                  -- For 'Warsztaty UI/UX Design'
                languages TEXT,                         -- For 'Międzynarodowy klub językowy'
                area_of_interest TEXT,                  -- For 'Seminarium przedsiębiorczości'
                distance TEXT,                          -- For 'Maraton uniwersytecki'
                artistic_interests TEXT,                -- For 'Wystawa sztuki studenckiej'
                participation_in_cv_workshops TEXT,     -- For 'Dzień kariery'
                professional_area_of_interest TEXT,     -- For 'Dzień kariery'
                created_at TEXT DEFAULT CURRENT_TIMESTAMP -- Timestamp for record creation
            )
        ''')
        conn.commit()

# Initialize the database
init_db()

# API endpoint for registration
@app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    try:
        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()
            # Insert data into the registration table
            cursor.execute('''
                INSERT INTO registration (
                    event_name, name, email, phone, field_of_study, company,
                    workshops, ticket_type, experience_level, languages,
                    area_of_interest, distance, artistic_interests,
                    participation_in_cv_workshops, professional_area_of_interest,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                data['event_name'],
                data['name'],
                data['email'],
                data.get('phone'),
                data.get('field_of_study'),
                data.get('company'),
                data.get('workshops'),
                data.get('ticket_type'),
                data.get('experience_level'),
                data.get('languages'),
                data.get('area_of_interest'),
                data.get('distance'),
                data.get('artistic_interests'),
                data.get('participation_in_cv_workshops'),
                data.get('professional_area_of_interest'),
                datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # Manually set timestamp
            ))
            conn.commit()
        return jsonify({'message': 'Registration successful!'}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# API endpoint to fetch all registrations (optional for testing)
@app.route('/api/registrations', methods=['GET'])
def get_registrations():
    try:
        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()
            # Fetch all data from the registration table
            cursor.execute('SELECT * FROM registration')
            rows = cursor.fetchall()
            # Format the data as JSON
            registrations = [
                {
                    'id': row[0],
                    'event_name': row[1],
                    'name': row[2],
                    'email': row[3],
                    'phone': row[4],
                    'field_of_study': row[5],
                    'company': row[6],
                    'workshops': row[7],
                    'ticket_type': row[8],
                    'experience_level': row[9],
                    'languages': row[10],
                    'area_of_interest': row[11],
                    'distance': row[12],
                    'artistic_interests': row[13],
                    'participation_in_cv_workshops': row[14],
                    'professional_area_of_interest': row[15],
                    'created_at': row[16]
                }
                for row in rows
            ]
        return jsonify(registrations)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
